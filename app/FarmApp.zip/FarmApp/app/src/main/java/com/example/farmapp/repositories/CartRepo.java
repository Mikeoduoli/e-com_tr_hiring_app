package com.example.farmapp.repositories;

public class CartRepo {
}
